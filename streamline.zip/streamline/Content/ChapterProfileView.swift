//
//  ChapterProfileView.swift
//  streamline
//
//  Created by Matt Forgacs on 9/26/21.
//

import SwiftUI

struct ChapterProfileView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ChapterProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ChapterProfileView()
    }
}
