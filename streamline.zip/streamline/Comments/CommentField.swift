//
//  CommentField.swift
//  streamline
//
//  Created by Matt Forgacs on 10/2/21.
//

import SwiftUI

struct CommentField: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CommentField_Previews: PreviewProvider {
    static var previews: some View {
        CommentField()
    }
}
